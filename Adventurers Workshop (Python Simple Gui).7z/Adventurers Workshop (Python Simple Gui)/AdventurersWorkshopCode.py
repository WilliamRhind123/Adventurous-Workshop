import random
import PySimpleGUI as sg
import os
import json

# File paths for images (Example paths; adjust as needed)
folderPath = os.path.dirname(os.path.abspath(__file__))
ShopImagePNG = os.path.join(folderPath, "ShopImagePNG.png")
BearImage = os.path.join(folderPath, "BearResizedPNG.png")
GoblinImage = os.path.join(folderPath, "GoblinPNG.png")
GoldImage = os.path.join(folderPath, "CoinsPNG.png")
MushroomImage = os.path.join(folderPath, "MushroomPNG.png")
MerchantImage = os.path.join(folderPath, "MercentPNG.png")
PathOfAdventureImage = os.path.join(folderPath, "PathOfAdventurePNG.png")
SkullAndBonesImage = os.path.join(folderPath, "SkullAndBonesPNG.png")
# Starting inventory and wallet balance within Inventory dictionary
Inventory = {
    "Sword": 0,
    "Armour": 0,
    "BearHeadTrophy": 0,
    "Opalesent Sapphire": 0,
    "Mushroom": 0,
    "Health Potion": 3,
    "wallet_balance": 20.0,  # Wallet balance now part of the inventory
    "health": 100  # Health now part of the inventory
}

# Shopping cart
cart = []

Descriptions = {
    "Sword": "Sharp Long Blade Used For Defeating Your Foes.",
    "Armour": "Strong Armour Made From Bear Hide Reduces Incoming Damage by 3",
    "BearHeadTrophy": "A Valueble possesion only for the rich, has no perpose just to flex.",
    "Opalesent Sapphire": "A Smalle Blue Gemstone That many find precious maybe someone would be willing to buy it from you?"
}

# Function to load inventory from file
def load_inventory():
    """Load the inventory from a file"""
    global Inventory
    if os.path.exists("inventory.json"):
        with open("inventory.json", "r") as file:
            Inventory = json.load(file)
            # Ensure wallet_balance and health are always set
            if 'wallet_balance' not in Inventory:
                Inventory['wallet_balance'] = 10.0  # Default value if missing
            if 'health' not in Inventory:
                Inventory['health'] = 100  # Default value if missing
    else:
        # If the file doesn't exist, use the default inventory
        print("No saved inventory found. Starting with default inventory.")

# Function to save inventory to a file
def save_inventory():
    """Save the inventory to a file"""
    with open("inventory.json", "w") as file:
        json.dump(Inventory, file)

# Game Initialization
load_inventory()  # Load inventory at the start of the game

# Function to add product to the cart with a specified quantity
def add_to_cart(product_name, price, quantity):
    for _ in range(quantity):
        cart.append((product_name, price))
    update_cart_display()

    # Update inventory
    if product_name in Inventory:
        Inventory[product_name] += quantity
    else:
        Inventory[product_name] = quantity

# Update the cart display and wallet balance
def update_cart_display():
    cart_display = ""
    total = 0
    for item in cart:
        cart_display += f"{item[0]} - ${item[1]:.2f}\n"
        total += item[1]
    
    window['-CART-'].update(cart_display)
    window['-TOTAL-'].update(f"Total: ${total:.2f}")
    window['-WALLET-'].update(f"Wallet Balance: ${Inventory['wallet_balance']:.2f}")

# Function to handle checkout
def checkout():
    total = sum(item[1] for item in cart)
    
    if total > Inventory['wallet_balance']:
        sg.popup("Insufficient Funds", "You do not have enough money to complete this purchase!")
    else:
        Inventory['wallet_balance'] -= total
        sg.popup("Checkout", f"Thank you for your purchase!\nTotal: ${total:.2f}")
        cart.clear()
        update_cart_display()

# Function to show quantity selection popup
def select_quantity(product_name, price):
    layout = [
        [sg.Text(f"Select quantity for {product_name}")],
        [sg.Text(f"Description: {Descriptions[product_name]}")],
        [sg.Combo([1, 2, 3, 4, 5], default_value=1, key="-QUANTITY-", size=(10, 1))],
        [sg.Button("Add to Cart"), sg.Button("Cancel")]
    ]

    # Create the popup window for quantity selection
    quantity_window = sg.Window(f"Select Quantity for {product_name}", layout)
    
    while True:
        event, values = quantity_window.read()
        
        if event == sg.WIN_CLOSED or event == "Cancel":
            quantity_window.close()
            break
        
        if event == "Add to Cart":
            quantity = values["-QUANTITY-"]
            add_to_cart(product_name, price, quantity)
            quantity_window.close()
            break

def reset_inventory():
    global Inventory
    Inventory = {
        "Sword": 0,
        "Armour": 0,
        "BearHeadTrophy": 0,
        "Opalesent Sapphire": 0,
        "Mushroom": 0,
        "Health Potion": 3,
        "wallet_balance": 20.0,
        "health": 100
    }
    save_inventory()


# Function to handle the death screen when health reaches 0
def death_screen():
    layout = [
        [sg.Text("You have died! Your journey has come to an end.")],
        [sg.Image(filename=SkullAndBonesImage, subsample = 3)],
        [sg.Text("Do you want to try again, everything will be reset?")],
        [sg.Button("Retry")]
    ]

    death_window = sg.Window("Game Over", layout)

    while True:
        event, _ = death_window.read()

        if event == sg.WIN_CLOSED:
            death_window.close()
            break

        if event == "Retry":
            death_window.close()
            reset_inventory()
            

# Adventure Class
# Adventure Class
class Adventure:
    def __init__(self):
        self.events = {
            "bear": {"message": "You face a bear in the wild, would you like to fight it?", "reward": None, "penalty": 20, "item_needed": "Sword", "image": BearImage},
            "goblin": {"message": "You face a goblin in the wild, would you like to fight it?", "reward": None, "penalty": 10, "item_needed": "Sword", "image": GoblinImage},
            "mushroom": {"message": "You find a strange mushroom in the wild, would you like to collect it?", "reward": "Mushroom", "penalty": None, "item_needed": None, "image": MushroomImage},
            "gold": {"message": "You come across a bag of gold sitting beside a tree, would you like to collect it", "reward": 5, "penalty": None, "item_needed": None, "image": GoldImage},
            "merchant": {"message": "You find a wandering merchant willing to trade, would you like to talk to him?", "reward": "Trade", "penalty": None, "item_needed": "Opalesent Sapphire", "image": MerchantImage},
        }

    def encounter(self):
        chance = random.randint(50, 100)
        event_key = self.get_event_key(chance)
        event = self.events[event_key]
        
        event_message = event["message"]
        event_image = event["image"]
        
        layout = [
            [sg.Text(event_message)],
            [sg.Image(filename=event_image)],
            [sg.Button("Yes"), sg.Button("No")]
        ]

        window = sg.Window("Adventure Encounter", layout)
        event, _ = window.read()

        if event == "Yes":
            self.handle_event(event_key)
        elif event == "No":
            sg.popup("You chose to steer clear of the event.")
        
        window.close()

    def get_event_key(self, chance):
        if chance >= 90:
            return "bear"
        elif chance >= 80:
            return "goblin"
        elif chance >= 70:
            return "mushroom"
        elif chance >= 60:
            return "gold"
        elif chance >= 50:
            return "merchant"
        return "none"

    def handle_event(self, event_key):
        event = self.events[event_key]
        
        if event_key == "merchant":
            self.handle_merchant_event()
        else:
            if event["reward"]:
                self.reward(event["reward"])
            if event["penalty"]:
                self.penalty(event["penalty"], event["item_needed"])

    def handle_merchant_event(self):
        if Inventory.get("Opalesent Sapphire", 0) > 0:
            Inventory["wallet_balance"] += 25  # Give 50 gold
            Inventory["Opalesent Sapphire"] -= 1  # Remove 1 Opalesent Sapphire from inventory
            sg.popup("The merchant gives you 25 gold in exchange for your Opalesent Sapphire!")
        else:
            sg.popup("You have nothing the merchant needs!")

    def reward(self, reward):
        if reward == "Mushroom":
            Inventory["Mushroom"] += 1
            sg.popup("You collect a mushroom!")
        elif reward == 5:
            Inventory['wallet_balance'] += reward
            sg.popup(f"You collect {reward} gold!")
        elif reward == "Trade":
            sg.popup("You have nothing the merchant needs!")

    def penalty(self, penalty, item_needed):
        if item_needed and Inventory.get(item_needed, 0) == 0:
            global health
            Inventory['health'] -= penalty - 3*(Inventory["Armour"])  # armour reduces damage
            sg.popup(f"You got hurt and lost {penalty - 3*(Inventory['Armour'])} health!")
            if Inventory['health'] <= 0:
                death_screen()
        elif item_needed and Inventory.get(item_needed, 0) > 0:
            sg.popup("You fight off the enemy with your sword!")
        elif not item_needed:
            sg.popup("You fight off the enemy with your sword!")


# Layout for the Game tab
GameTab_layout = [
    [sg.Button("   ", image_filename="PathOfAdventurePNG.png", size=(75, 2))]
]

# Layout for the Inventory tab
InventoryTab_layout = [
    [sg.Text("What you have Gathered Across Your Adventures", font=("Helvetica", 14))],
    [sg.Multiline("", size=(60, 12), key="-INVENTORY-", disabled=True, font=("Helvetica", 16))],
    [sg.Button("USE HEALTH POTION", size = (75,2))]
]

ShopTab_layout = [
    [sg.Text("Welcome to the Shop!", size=(30, 1), font=("Helvetica", 16))],
    [sg.Text("Products", font=("Helvetica", 12))],
    [sg.Button("Sword - $10.00", key="-PRODUCT-SWORD"), 
     sg.Button("Armour - $5.00", key="-PRODUCT-ARMOUR"),
     sg.Button("BearHeadTrophy - $50.00", key="-PRODUCT-BEARHEADTROPHY"),
     sg.Button("Opalesent Sapphire - $2.00", key="-PRODUCT-GEM")],
    [sg.Text("Your Cart:", font=("Helvetica", 12))],
    [sg.Multiline("", size=(30, 6), key="-CART-", disabled=True)],
    [sg.Text("Total: $0.00", key="-TOTAL-", font=("Helvetica", 12))],
    [sg.Text(f"Wallet Balance: ${Inventory['wallet_balance']:.2f}", key="-WALLET-", font=("Helvetica", 12))],
    [sg.Button("Checkout")]  
]

MainMenu_layout = [
    [sg.Text("     WELCOME TO THE ADVENTURERS WORKSHOP!", justification="center", font=("Helvetica", 16))],
    [sg.Image("MainMenuImagePNG.png", subsample = 2)]
]

Setting_layout = [
    [sg.Button("RESET DATA SETTINGS", size = (75, 75))]
]

layout = [
    [
        sg.TabGroup(
            [
                [sg.Tab("MainMenu", MainMenu_layout), 
                 sg.Tab("Shop", ShopTab_layout), 
                 sg.Tab("Game", GameTab_layout), 
                 sg.Tab("Inventory", InventoryTab_layout),
                 sg.Tab("Settings", Setting_layout)]
            ],
            title_color='blue',
        )
    ]
]

window = sg.Window("Adventurers Workshop", layout, size=(600, 400))

adventure = Adventure()

# Event loop
while True:
    event, values = window.read()

    if event == sg.WIN_CLOSED:
        break

    if event == "   ":
        adventure.encounter()

    if event == "USE HEALTH POTION":
        if Inventory["Health Potion"] > 0:
            Inventory["health"] += 25
            Inventory["Health Potion"] -= 1
            sg.popup("You Used A Health Potion! You Gained 25 Health!")
        else: 
            sg.popup("You Don't Have Any Health Potions Left!")

    # Update Inventory display dynamically
    inventory_display = ""
    for item, count in Inventory.items():
        inventory_display += f"{item}: {count}\n"
    window['-INVENTORY-'].update(inventory_display)

    # Now using 'Inventory['health']' in the inventory display
    window['-INVENTORY-'].update(inventory_display)

    if event == "Exit":
        confirm_exit = sg.popup_yes_no("Are you sure you want to exit?", title="Exit Confirmation")
        if confirm_exit == "Yes":
            break 

    # Reset Inventory And Player Data I could use the fucction from earlier but I wanted to show you that I  could do it several ways, including this loop
    if event == "RESET DATA SETTINGS": 
        ConfirmDataREset = sg.popup_yes_no("Are you sure you want to reset game data?", title="Reset Confirmation")
        if ConfirmDataREset == "Yes":
            for item in Inventory:
                if item != 'wallet_balance' and item != 'health':  # Don't reset wallet_balance and health
                    Inventory[item] = 0
            Inventory['Health Potion'] = 3
            Inventory['wallet_balance'] = 20.0  # Reset wallet balance
            Inventory['health'] = 100  # Reset health
            save_inventory()

    # Handle adding products to the cart and showing quantity selection
    if event == "-PRODUCT-SWORD":
        select_quantity("Sword", 10.0)
    elif event == "-PRODUCT-ARMOUR":
        select_quantity("Armour", 5.0)
    elif event == "-PRODUCT-BEARHEADTROPHY":
        select_quantity("BearHeadTrophy", 50.00)
    elif event == "-PRODUCT-GEM":
        select_quantity("Opalesent Sapphire", 2.0)

    # Handle checkout button click
    if event == "Checkout":
        checkout()

window.close()
save_inventory()
